'use strict';
module.change_code = 1;
var _ = require('lodash');
var Skill = require('alexa-app');
var RECIPE_SESSION_KEY = 'recipe_reader';
var skillService = new Skill.app('masterchef');
var DatabaseHelper = require('./database_helper');
var databaseHelper = new DatabaseHelper();
var MAIN_PROMPT = 'Recipe assistant, what recipe would you like to make? Say info to get a list of possible commands.';

//Session attributes
var currentDialog = 'Main';
var currentIngredients;
var currentDirections;
var ingredientsIndex = 0;
var directionsIndex = 0;

skillService.pre = function(request, response, type) {
  databaseHelper.createRecipeTable();
};

skillService.intent('advanceDirectionIntent',
  function(request, response) {
    if (currentDialog === 'Directions') {
      if (directionsIndex == currentDirections.length - 1) {
        response.say(currentDirections[directionsIndex] 
            + '. That was the final step. Say start again to start again. '
            + 'Say main menu to go back to the main dialogue.');
        directionsIndex = -1; //-1 means that we have just finished saying the final step.
        response.shouldEndSession(false);
        response.send();
        return false;
      }
      response.say(currentDirections[directionsIndex]);
      directionsIndex++;
      response.shouldEndSession(false);
      response.send();
      return false;
    } else {
      response.say('You are not in the directions step right now. Say main menu to go back to the main menu.'
          + ' Say next ingredient if you are in the ingredients step.');
      response.shouldEndSession(false);
      response.send();
      return false;
    }
  }
);

skillService.intent('advanceIngredientIntent',
  function(request, response) {
    if (currentDialog === 'Ingredients') {
      if (ingredientsIndex == currentIngredients.length - 1) {
        response.say(currentIngredients[ingredientsIndex] 
            + '. Now that you have all the ingredients, let us get cooking. '
            + 'Please say read recipe or start to begin. '
            + 'Say main menu to go back to the main dialogue.');
        ingredientsIndex = -1;  //-1 means that we have just finished saying the final ingredient.
        currentDialog = 'Directions';
        response.shouldEndSession(false);
        response.send();
        // return false;
      } else {

        response.say(currentIngredients[ingredientsIndex]);
        ingredientsIndex++;
        response.shouldEndSession(false);
        response.send();
      }
      // return false;
    } else {
      response.say('You are not in the ingredients step right now. Say main menu to go back to the main menu.');
      response.shouldEndSession(false);
      response.send();
      // return false;
    }
  }
);

skillService.intent('lastIngredientIntent',
  function(request, response) {
    if (ingredientsIndex == -1) {
      response.say(currentIngredients[currentIngredients.length - 1]
            + '. Now that you have all the ingredients, let us get cooking. '
            + 'Please say read recipe or start to begin. '
            + 'Say main menu to go back to the main dialogue.');
      response.shouldEndSession(false);
      response.send();
      // return false;      
    } else if (currentDialog === 'Ingredients') {
      response.say(currentIngredients[--ingredientsIndex]);
      ingredientsIndex++;
      response.shouldEndSession(false);
      response.send();
      // return false;
    } else {
      response.say('You are not in the ingredients step right now. Say main menu to go back to the main menu.');
      response.shouldEndSession(false);
      response.send();
    }
  }
);

skillService.intent('lastDirectionIntent',
  function(request, response) {
    if (directionsIndex == -1) {
      response.say(currentDirections[currentDirections.length - 1]
            + '. That was the final step. Say start again to start again.'
            + 'Say main menu to go back to the main dialogue.');
      response.shouldEndSession(false);
      response.send();
      return false;      
    }
    if (currentDialog === 'Directions') {
      response.say(currentDirections[--directionsIndex]);
      directionsIndex++;

      response.shouldEndSession(false);
      response.send();
      return false;
    } else {
      response.say('You are not in the directions step right now. Say main menu to go back to the main menu.');
      response.shouldEndSession(false);
      response.send();
      return false;
    }
  }
);

skillService.intent('getIngredientIntent',
  function(request, response) {
    if (!(currentDialog === 'Ingredients')) {
      response.say('There is no recipe loaded or we are not on the recipe ingredients step yet. Say main menu to go back to the main menu.');
      response.shouldEndSession(false);
      response.send();
      return false;
    }
    response.say(currentIngredients[0]);
    ingredientsIndex = 1;
    response.shouldEndSession(false);
    response.send();
    return false;
  }
);

skillService.intent('getDirectionIntent',
  function(request, response) {
    if (!(currentDialog === 'Directions')) {
      response.say('There is no recipe loaded or we are not on the recipes directions step yet. Say main menu to go back to the main menu.');
      response.shouldEndSession(false);
      response.send();
      return false;
    }
    response.say(currentDirections[0]);
    ingredientsIndex = 0;
    directionsIndex = 1;
    response.shouldEndSession(false);
    response.send();
    return false;
  }
);

skillService.launch(function(request, response) {
  var prompt = 'Welcome to Master Chef! Say begin to start.';
  response.say(prompt);
  response.shouldEndSession(false);
  response.send();
});

skillService.intent('getBaconEggsRecipeIntent',
  function(request, response) {
      databaseHelper.readRecipeData('Bacon and Eggs').then(function(result) {
      currentIngredients = result['Ingredients'].split(',');
      currentDirections = result['Directions'].split(',');
      currentDialog = 'Ingredients';
      return 'Recipe loaded sucessfully. Say ingredients to start.';
    }).then(function(prompt) {
      response.say(prompt);
      response.shouldEndSession(false).send();
    });
    return false;
  }
);

skillService.intent('getSteakRecipeIntent',
  function(request, response) {
      databaseHelper.readRecipeData('Steak').then(function(result) {
      currentIngredients = result['Ingredients'].split(',');
      currentDirections = result['Directions'].split(',');
      currentDialog = 'Ingredients';
      return 'Recipe loaded sucessfully. Say ingredients to start.';
    }).then(function(prompt) {
      response.say(prompt);
      response.shouldEndSession(false).send();
    });
    return false;
  }
);

skillService.intent('getFriedRiceRecipeIntent',
  function(request, response) {
      databaseHelper.readRecipeData('Fried Rice').then(function(result) {
      currentIngredients = result['Ingredients'].split(',');
      currentDirections = result['Directions'].split(',');
      currentDialog = 'Ingredients';
      return 'Recipe loaded sucessfully. Say ingredients to start.';
    }).then(function(prompt) {
      response.say(prompt);
      response.shouldEndSession(false).send();
    });
    return false;
  }
);

skillService.intent('getCerealRecipeIntent',
  function(request, response) {
      databaseHelper.readRecipeData('Cereal').then(function(result) {
      currentIngredients = result['Ingredients'].split(',');
      currentDirections = result['Directions'].split(',');
      currentDialog = 'Ingredients';
      return 'Recipe loaded sucessfully. Say ingredients to start.';
    }).then(function(prompt) {
      response.say(prompt);
      response.shouldEndSession(false);
      response.send();
    });
    return false;
  }
);

skillService.intent('getPastaRecipeIntent',
  function(request, response) {
      databaseHelper.readRecipeData('Pasta').then(function(result) {
      currentIngredients = result['Ingredients'].split(',');
      currentDirections = result['Directions'].split(',');
      currentDialog = 'Ingredients';
      return 'Recipe loaded sucessfully. Say ingredients to start.';
    }).then(function(prompt) {
      response.say(prompt);
      response.shouldEndSession(false);
      response.send();
    });
    return false;
  }
);

skillService.intent('getOatmealRecipeIntent',
  function(request, response) {
      databaseHelper.readRecipeData('Oatmeal').then(function(result) {
      currentIngredients = result['Ingredients'].split(',');
      currentDirections = result['Directions'].split(',');
      currentDialog = 'Ingredients';
      return 'Recipe loaded sucessfully. Say ingredients to start.';
    }).then(function(prompt) {
      response.say(prompt);
      response.shouldEndSession(false);
      response.send();
    });
    return false;
  }
);


skillService.intent('helpIntent',
  function(request, response) {
    var prompt = 'Here is a list of things you can say: '
        + '1. oatmeal. '
        + '2. bacon and eggs. '
        + '3. steak. '
        + '4. fried rice. '
        + '5. cereal. '
        + '6. pasta. '
        + 'To choose one of these options, either say '
        + 'I would like to make x where x is one of the supported recipes. or say '
        + 'Find x where x is one of the supported recipes: '
        + 'If you need to go back, say main menu.';
    response.say(prompt);
    response.shouldEndSession(false);
    response.send();
    // return false;
  }
);

skillService.intent('startIntent',
  function(request, response) {
    currentDialog = 'Main';
    directionsIndex = 0;
    ingredientsIndex = 0;
    response.say(MAIN_PROMPT);
    response.shouldEndSession(false);
    response.send();
  }
);

skillService.intent('startAgainIntent',
  function(request, response) {
    if (currentDialog === 'Ingredients' || ingredientsIndex == -1) {
      ingredientsIndex = 0;
      currentDialog = 'Ingredients';
      response.say(currentIngredients[ingredientsIndex]);
      ingredientsIndex++;
      response.shouldEndSession(false);
      response.send();
      // return false;      
    } else if (currentDialog === 'Directions') {
      directionsIndex = 0;
      response.say(currentDirections[directionsIndex]);
      directionsIndex++;
      response.shouldEndSession(false);
      response.send();
    } else {
      response.say('Cannot start again, you are in the main dialogue. Say main menu to repeat options.');
      response.shouldEndSession(false);
      response.send();
      // return false;        
    }
  }
);

skillService.intent('unknownIntent',
  function(request, response) {
    response.say('I am sorry, I did not understand that. Say main menu to go back to the main menu.');
    response.shouldEndSession(false);
    response.send();
  }
);

skillService.intent('quitIntent',
  function(request, response) {
    if (currentDialog === 'Main') {
      var prompt = 'Thank you for using Master Chef. Now quitting the app.';
      response.say(prompt);
      response.shouldEndSession(true);
    } else {
      currentDialog = 'Main';
      directionsIndex = 0;
      ingredientsIndex = 0;
      response.say(MAIN_PROMPT);
      response.shouldEndSession(false);
      response.send();
    }
  }
);

module.exports = skillService;
