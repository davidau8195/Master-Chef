'use strict';
module.change_code = 1;
var _ = require('lodash');
var DATA_TABLE_NAME = 'Recipes';
var dynasty = require('dynasty')({});

function RecipeHelper() {}
var recipeTable = function() {
  return dynasty.table(DATA_TABLE_NAME);
};

RecipeHelper.prototype.createRecipeTable = function() {
  return dynasty.describe(DATA_TABLE_NAME)
    .catch(function(error) {
      return dynasty.create(DATA_TABLE_NAME, {
        key_schema: {
          hash: ['RecipeName', 'string']
        }
      });
    });
};

RecipeHelper.prototype.readRecipeData = function(userId) {
  return recipeTable().find(userId)
    .then(function(result) {
      return result;
    })
    .catch(function(error) {
      console.log(error);
    });
};

module.exports = RecipeHelper;
