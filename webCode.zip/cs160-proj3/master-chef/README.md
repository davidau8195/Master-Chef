# react-toolbox-example

### Getting Started
1. Clone this repository
2. Run `npm install && npm start`
3. Visit `0.0.0.0:8080` in your browser
