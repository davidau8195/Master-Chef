/**
 * Created by jaesunglee on 13/03/2017.
 */
import React from 'react';
import { Button } from 'react-toolbox/lib/button';
import theme from './RecipeButton.css';

const RecipeButton = (props) => <Button {...props} theme={theme} />;
export default RecipeButton;