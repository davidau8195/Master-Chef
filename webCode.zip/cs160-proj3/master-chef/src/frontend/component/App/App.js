import React from 'react';
import AppBar from 'react-toolbox/lib/app_bar';
import RecipeButton from '../RecipeButton/RecipeButton';
import Dialog from 'react-toolbox/lib/dialog';
import style from './App.css';
import Input from 'react-toolbox/lib/input';
import {Card, CardMedia, CardTitle, CardText, CardActions} from 'react-toolbox/lib/card';
import {Button} from 'react-toolbox/lib/button';
import ProgressBar from 'react-toolbox/lib/progress_bar';
import Autocomplete from 'react-toolbox/lib/autocomplete';

class App extends React.Component {

  constructor() {
    super();

    this.onAddRecipeClick = this.onAddRecipeClick.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
    this.onAddRecipeConfirm = this.onAddRecipeConfirm.bind(this);

    this.state = {
      active: false,
      ingredientsAction: false,
      recipeName: '',
      recipeIngredients: '',
      recipeDirections: '',
      recipeImageUrl: '',
      recipes: null,
      isInitialized: false,
    };

  }

  componentDidMount() {
    this.fetchRecipes();
  }

  /**
   * Data Loading method that uses Fetch API to
   * load data from AWS DynamoDB.
   * This method fetches all recipe data.
   */
  fetchRecipes() {
    fetch(`https://s6x2g295f4.execute-api.us-east-1.amazonaws.com/prod/RecipeUpdater?TableName=Recipes`,
      {
        mode: 'cors',
        method: 'GET',
      })
      .then(response => response.json())
      .then(json => {
        this.setState({recipes: json.Items});
      })
      .catch(err => {
        console.log(err);
      });
  }

  /**
   * Data loading method that uses Fetch API to
   * update data to AWS DynamoDB.
   * This method posts a specified recipe.
   */
  updateRecipes(recipeName, ingredients, directions, url) {
    fetch(`https://s6x2g295f4.execute-api.us-east-1.amazonaws.com/prod/RecipeUpdater`,
      {
        mode: 'cors',
        method: 'POST',
        body: JSON.stringify({
          'TableName': 'Recipes',
          'Item': {
            'RecipeName': recipeName,
            'Ingredients': ingredients,
            'Directions': directions,
            'ImageURL': url,
          }
        }),
      })
      .then(response => {
        this.setState({
          recipeName: '',
          recipeIngredients: '',
          recipeDirections: '',
          recipeImageUrl: '',
          isInitialized: false,
        });
        this.fetchRecipes();
      })
      .catch(err => {
        console.log(err);
      });
  }

  handleToggle() {
    this.setState({active: !this.state.active});
  }

  handleInputChange(name, value) {
    this.setState({[name]: value});
  }

  onAddRecipeClick() {
    this.setState({active: !this.state.active});
  }

  renderRecipes() {
    if (!this.state.recipes) {
      return (
        <div className={style.contents}>
          <ProgressBar className={style.progress}
                       type='circular'
                       mode='indeterminate'
                       multicolor/>
        </div>
      );
    }

    this.recipeNames = [];
    const recipesCards = this.state.recipes.map((recipe, idx) => {
      console.log(recipe);
      this.recipeNames.push(recipe.RecipeName);
      return (
        <Card key={idx}
              style={{width: '350px', margin: '20px'}}>
          <CardTitle
            avatar={recipe.ImageURL}
            title={recipe.RecipeName}
          />
          <CardMedia
            aspectRatio="wide"
            image={recipe.ImageURL}
          />
          <CardText>Learn to cook {recipe.RecipeName}!</CardText>
          <CardActions >
            <Button icon="shopping_basket" label="See Ingredients" primary onClick={() => {
              this.props.router.push(`/ingredient?name=${encodeURIComponent(recipe.RecipeName)}`);
            }}/>
            <Button label="Open" raised primary onClick={() => {
              this.props.router.push(`/recipe?name=${encodeURIComponent(recipe.RecipeName)}`);
            }}/>
          </CardActions>
        </Card>
      );
    });
    return (
      <div>
        <Autocomplete
          icon="search"
          className={style.search}
          direction="down"
          label="Search Recipe"
          source={this.recipeNames}
          value={this.state.recipes}
        />
        <div className={style.contents}>
          {recipesCards}
        </div>
      </div>
    );
  }

  onAddRecipeConfirm() {
    this.setState({active: !this.state.active});
    console.log("In onAddRecipeConfirm");
    console.log(this.state.recipeName);
    console.log(this.state.recipeIngredients);
    console.log(this.state.recipeDirections);
    console.log(this.state.recipeImageUrl);
    if (this.state.recipeName && this.state.recipeIngredients && this.state.recipeDirections && this.state.recipeImageUrl) {
      console.log("In onAddRecipeConfirm sent update message to db.");
      this.updateRecipes(this.state.recipeName,
        this.state.recipeIngredients,
        this.state.recipeDirections,
        this.state.recipeImageUrl);
    }
  }

  renderDialog() {
    const actions = [
      {label: "Cancel", onClick: this.handleToggle},
      {label: "Add Recipe", onClick: this.onAddRecipeConfirm, raised: true, primary: true}
    ];
    return (
      <Dialog
        actions={actions}
        active={this.state.active}
        onEscKeyDown={this.handleToggle}
        onOverlayClick={this.handleToggle}
        title='Add New Recipe'>
        <section>
          <Input type='text'
                 label='Recipe Name'
                 name='recipeName'
                 value={this.state.recipeName}
                 onChange={this.handleInputChange.bind(this, 'recipeName')}/>
          <Input type='text'
                 label='Ingredients'
                 name='recipe-ingredients'
                 value={this.state.recipeIngredients}
                 onChange={this.handleInputChange.bind(this, 'recipeIngredients')}/>
          <Input type='text'
                 label='Direction'
                 name='recipe-directions'
                 value={this.state.recipeDirections}
                 onChange={this.handleInputChange.bind(this, 'recipeDirections')}/>
          <Input type='text'
                 label='Image URL'
                 name='recipe-image-url'
                 value={this.state.recipeImageUrl}
                 onChange={this.handleInputChange.bind(this, 'recipeImageUrl')}/>
        </section>
      </Dialog>
    );
  }

  render() {
    return (
      <div className={style.container}>
        <AppBar title='Berkeley Master Chef' leftIcon="settings">
          <RecipeButton icon="add" label="Add New Recipe" onClick={this.onAddRecipeClick}/>
        </AppBar>
        {this.renderRecipes()}
        {this.renderDialog()}
      </div>
    );
  }
}

export default App;
