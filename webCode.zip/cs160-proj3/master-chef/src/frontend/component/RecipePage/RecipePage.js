import React, {PropTypes} from 'react';
import style from './RecipePage.css';
import AppBar from 'react-toolbox/lib/app_bar';
import ProgressBar from 'react-toolbox/lib/progress_bar';
import RecipeButton from '../RecipeButton/RecipeButton';
import {List, ListItem, ListSubHeader, ListDivider} from 'react-toolbox/lib/list';
import {Card, CardMedia, CardTitle, CardText, CardActions} from 'react-toolbox/lib/card';


class RecipePage extends React.Component {

  constructor() {
    super();

    this.state = {
      isInitialized: false,
    };

    this.recipe = null;
  }

  componentDidMount() {
    this.fetchRecipes();
  }

  fetchRecipes() {
    fetch(`https://s6x2g295f4.execute-api.us-east-1.amazonaws.com/prod/RecipeUpdater?TableName=Recipes`,
      {
        mode: 'cors',
        method: 'GET',
      })
      .then(response => response.json())
      .then(json => {
        this.setState({recipes: json.Items});
        const targetName = this.props.location.query.name;
        this.state.recipes.map(recipe => {
          if (recipe.RecipeName === targetName) {
            this.recipe = recipe;
            this.setState({isInitialized: true});
          }
        });
      })
      .catch(err => {
        console.log(err);
      });
  }

  renderIngredients() {
    const ingredients = this.recipe.Ingredients.split(",");
    const ingredientItem = ingredients.map((ingredient, idx) => {
      console.log(ingredient);
      return (
        <div key={idx}>
          <ListItem caption={ingredient} ripple={false} leftIcon="shopping_basket"/>
        </div>
      );
    });
    return ingredientItem;
  }

  renderDirections() {
    const directions = this.recipe.Directions.split(",");
    const directionItem = directions.map((direction, idx) => {
      console.log(direction);
      return (
        <div key={idx}>
          <ListItem caption={`${idx + 1}. ${direction}`} ripple={false}/>
        </div>
      );
    });
    return directionItem;
  }

  renderRecipeDetail() {
    if (this.state.isInitialized) {
      return (
        <div className={style.contents}>
          <Card style={{width: '400px'}}>
            <CardMedia
              aspectRatio="wide"
              image={this.recipe.ImageURL}
            />
            <CardTitle
              title={this.recipe.RecipeName}
              subtitle={`Complete Guide for ${this.recipe.RecipeName}`}
            />
            <CardText>
              Please acquire below ingredients and follow directions to make {this.recipe.RecipeName}.
            </CardText>
            <List>
              <ListSubHeader caption='Ingredients'/>
              {this.renderIngredients()}
              <ListDivider/>
            </List>
            <List>
              <ListSubHeader caption='Directions'/>
              {this.renderDirections()}
            </List>
          </Card>
        </div>
      );
    } else {
      return (
        <div className={style.contents}>
          <ProgressBar className={style.progress}
                       type='circular'
                       mode='indeterminate'
                       multicolor/>
        </div>
      );
    }
  }


  render() {
    return (
      <div className={style.container}>
        <AppBar title='Berkeley Master Chef'>
          <RecipeButton icon="home" label="Back to Home" primary onClick={() => {
            this.props.router.push("/");
          }}/>
        </AppBar>
        {this.renderRecipeDetail()}
      </div>
    );
  }
}

export default RecipePage;
