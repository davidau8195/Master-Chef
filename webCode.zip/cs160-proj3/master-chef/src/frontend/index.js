import React from 'react';
import ReactDOM from 'react-dom';
import App from './component/App/App';
import RecipePage from './component/RecipePage/RecipePage';
import IngredientPage from './component/IngredientPage/IngredientPage';
import { AppContainer } from 'react-hot-loader';
import { overrideComponentTypeChecker } from 'react-toolbox';
import { Router, Route, Link, IndexRoute, hashHistory, browserHistory } from 'react-router';

const rootEl = document.getElementById('app');
document.getElementById('app').style.height = "100%";
document.getElementById('app').style.width = "100%";

ReactDOM.render(
  <Router history={browserHistory}>
    <Route path="/" component={App}/>
    <Route path="/recipe" component={RecipePage}/>
    <Route path="/ingredient" component={IngredientPage}/>
  </Router>,
  rootEl
);

